window.onload = main;

async function getDataJSON(path){
    const data = await d3.json(path);
    console.log(data);
    return data;
}

async function get_dataJSON_Normalized(path) {
    const data = await getDataJSON(path);

    // Calcoliamo la somma totale dei valori
    const total = d3.sum(Object.values(data));

    // Creiamo i due oggetti separati
    const normalizedData = {};
    const stringData = {};

    for (let key in data) {
        // 1. Valore normalizzato numerico (es. 0.25)
        const normalizedVal = data[key] / total;
        normalizedData[key] = normalizedVal;

        // 2. Valore in stringa formattato in percentuale (es. "25%")
        // Usiamo d3.format per arrotondare e aggiungere il simbolo %
        stringData[key] = `${d3.format(".0%")(normalizedVal)}`;
    }

    // Restituisce un array contenente entrambi gli oggetti
    return [normalizedData, stringData];
}

async function main() {
    const dataTupla = await get_dataJSON_Normalized('./data/data.json');

    render_data(dataTupla);
}

// Dimensioni dell'SVG
const svgWidth = 900;
const svgHeight = 650;

// Margini interni del grafico
const margin = {top: 40, right: 40, bottom: 40, left: 40};
const chartWidth = svgWidth - margin.left - margin.right;
const chartHeight = svgHeight - margin.top - margin.bottom;

function render_data(dataTupla) {
    const [data, dataString] = dataTupla;

    console.log("DATA", data);

    const innerRadius = 100;
    const outerRadius = Math.min(chartWidth, chartHeight) / 2
        - Math.max(...Object.values(margin));

    const svg = d3.select("body")
        .append("svg")
        .attr('width', svgWidth)
        .attr('height', svgHeight);

    const group = svg.append('g')
        .attr('transform', `translate(${margin.left + chartWidth / 2}, 
            ${margin.top + chartHeight / 2})`)
        .attr('id', 'circleGroup');

    // Scala di colori
    const sortedKeys = Object.keys(data).sort((a, b) => data[b] - data[a]);
    const customColors = ["red", "orange", "yellow", "green", "blue"];
    const color = d3.scaleOrdinal()
        .domain(sortedKeys)
        .range(customColors);

    const pie = d3.pie().value(d => d[1]);
    const arcs = pie(Object.entries(data));

    const arcGenerator = d3.arc()
        .innerRadius(innerRadius)
        .outerRadius(outerRadius);

    // Evento per il click del mouse
    let selectedSlice = null; // Memorizza la fetta attualmente selezionata

    const MouseOnClick = function(event, d) {
        // 1. Rimuoviamo l'evidenziazione e il cerchio da QUALSIASI elemento precedentemente selezionato
        d3.selectAll('path').style("stroke-width", "2px").attr("stroke", "black");
        d3.selectAll('.centroid-circle').remove();

        // 2. Se l'utente ha cliccato sulla stessa fetta che era già attiva, la deselezioniamo (toggle)
        if (selectedSlice === this) {
            selectedSlice = null; // Reset dello stato
            return;
        }

        // 3. Altrimenti, attiviamo la nuova fetta cliccata
        selectedSlice = this;

        // Evidenziamo la fetta con bordo nero di 4px
        d3.select(this)
            .style("stroke-width", "4px")
            .attr("stroke", "black");

        // Calcoliamo il centroide della fetta usando l'arcGenerator
        // Nota: arcGenerator deve essere accessibile nello scope (oppure definito fuori)
        const [x, y] = arcGenerator.centroid(d);

        // Creiamo il cerchio nero nel centroide con raggio 4px
        d3.select('#circleGroup') // O il gruppo principale del tuo grafico a torta
            .append('circle')
            .attr('class', 'centroid-circle') // Classe per poterlo rimuovere facilmente dopo
            .attr('cx', x)
            .attr('cy', y)
            .attr('r', 4)
            .attr('fill', 'black');
    };

    group.selectAll('path')
        .data(arcs)
        .join('path')
        .attr('d', arcGenerator)
        .attr('fill', d => color(d.data[0]))
        .attr("stroke", "black")
        .attr("class", d => d.data[0])
        .style("stroke-width", "2px")
        .style("opacity", 0.8)
        .on('click', MouseOnClick)
}
